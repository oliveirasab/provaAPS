using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SabrinaAPS.Models
{
    public class Item
    {
        [Key]
        public int ItemId { get; set;}
        public double Preco { get; set;}
        public int Percentual { get; set;}
        public int Quantidade { get; set;}
    }
}