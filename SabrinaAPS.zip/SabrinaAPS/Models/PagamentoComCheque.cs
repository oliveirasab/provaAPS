using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SabrinaAPS.Models
{
    public class PagamentoComCheque : TipoDePagamento
    {
        public int Banco { get; set;}
        public string? NomeDoBanco { get; set;}
    }
}