using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SabrinaAPS.Models
{
    public class Pagamento
    {
        [Key]
        public int PagamId { get; set;}
        public DateTime DataLimite { get; set;}
        public double Valor { get; set;}
        public bool Pago { get; set;}
    }
}